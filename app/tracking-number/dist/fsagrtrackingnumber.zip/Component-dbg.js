sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("agr.fs.trackingnumber.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);