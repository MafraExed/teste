sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("agr.fs.trackingnumber.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map